# phplist-plugin-campaignslicer

[![Build Status](https://travis-ci.org/michield/phplist-plugin-campaignslicer.svg?branch=master)](https://travis-ci.org/michield/phplist-plugin-campaignslicer)

Allow sending to a subset of the total campaign.

This plugin will ask for a maximum to send in a campaign and will not send any further mails.

Once the maximum has been reached, you can set it to either mark the campaign as "Sent" or have it suspended, so you
can increase the maximum.
